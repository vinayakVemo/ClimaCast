const key = '0f02731cf63e9a5e3888ce2eb3c0e82f';
let searchval = document.getElementById("searchbar");
var btn = document.getElementById("sbbtn");
function oup(url){
    console.log(searchval.value);   
    var city = searchval.value;
    var url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${key}&units=metric`;
    async function WeatherChecker(){
        const response = await fetch(url);
        var data = await response.json();
        console.log(data);
        //now
        document.querySelector(".temp").innerHTML=data.list[0].main.temp+"°C";
        document.querySelector(".city").innerHTML=data.city.name;
        document.querySelector("#dt_main").innerHTML=(data.list[0].dt_txt).slice(0,10);

        //details
        document.querySelector("#humid").innerHTML="💧"+data.list[0].main.humidity+"%";
        document.querySelector("#pressure").innerHTML=data.list[0].main.pressure+"hpa";
        document.querySelector("#visibility").innerHTML=((data.list[0].visibility)/1000)+"km";
        document.querySelector("#feels").innerHTML=data.list[0].main.feels_like+"°C";
        document.querySelector("#wind").innerHTML=Math.trunc(data.list[0].wind.speed)+"Km/h";
        let wicon = document.querySelector('.weather-icon');
        const {icon} = data.list[0].weather[0];
        wicon.innerHTML = `<img src="icons/${icon}.png" class="weather-img">`;        
        //5days-forecast  
                //day-1
                let wicon1 = document.querySelector('.weather-icon-1');
                const icon1 = data.list[8].weather[0].icon;
            wicon1.innerHTML = `<img src="icons/${icon1}.png" class="weather-img-5d">`;
            document.querySelector("#temp_1").innerHTML=data.list[8].main.temp+"°C";
            document.querySelector('#des1').innerHTML=data.list[8].weather[0].description;
            var date = data.list[8].dt_txt;
            document.querySelector('#dt1d').innerHTML=date.slice(0,10);
                //day-2
                let wicon2 = document.querySelector('.weather-icon-2');
                const icon2 = data.list[16].weather[0].icon;
            wicon2.innerHTML = `<img src="icons/${icon2}.png" class="weather-img-5d">`;
            document.querySelector("#temp_2").innerHTML=data.list[16].main.temp+"°C";
            document.querySelector('#des2').innerHTML=data.list[16].weather[0].description;
            document.querySelector('#dt2d').innerHTML=(data.list[16].dt_txt).slice(0,10);
                //day-3
                let wicon3 = document.querySelector('.weather-icon-3');
                const icon3 = data.list[24].weather[0].icon;
            wicon3.innerHTML = `<img src="icons/${icon3}.png" class="weather-img-5d">`;
            document.querySelector("#temp_3").innerHTML=data.list[24].main.temp+"°C";
            document.querySelector('#des3').innerHTML=data.list[24].weather[0].description;
            document.querySelector('#dt3d').innerHTML=(data.list[24].dt_txt).slice(0,10);
                            //day-4
                let wicon4 = document.querySelector('.weather-icon-4');
                const icon4 = data.list[32].weather[0].icon;
            wicon4.innerHTML = `<img src="icons/${icon4}.png" class="weather-img-5d">`;
            document.querySelector("#temp_4").innerHTML=data.list[32].main.temp+"°C";
            document.querySelector('#des4').innerHTML=data.list[32].weather[0].description;
            document.querySelector('#dt4d').innerHTML=(data.list[32].dt_txt).slice(0,10);
                            //day-5
                let wicon5 = document.querySelector('.weather-icon-5');
                const icon5 = data.list[39].weather[0].icon;
            wicon5.innerHTML = `<img src="icons/${icon5}.png" class="weather-img-5d">`;
            document.querySelector("#temp_5").innerHTML=data.list[39].main.temp+"°C";
            document.querySelector('#des5').innerHTML=data.list[39].weather[0].description;
            document.querySelector('#dt5d').innerHTML=(data.list[39].dt_txt).slice(0,10);
    }
    WeatherChecker(url).then(
        function (){
            console.log("success");
        },
        function (){
            alert("city not found🥺!");
        }
    );

}
const btn2 = document.getElementById("curr_loc")
btn2.addEventListener('click',geoloc)

function geoloc() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
    } else {
      alert( "Geolocation is not supported by this browser.");
    }
  }
  
  function showPosition(position) {
    var lat = position.coords.latitude;
    var long = position.coords.longitude;
    console.log(lat+" "+long);
    function oup2(url){
        var url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${long}&appid=${key}&units=metric`;
        async function WeatherChecker(){
            const response = await fetch(url);
            var data = await response.json();
            console.log(data);
            //now
            document.querySelector(".temp").innerHTML=data.list[0].main.temp+"°C";
            document.querySelector(".city").innerHTML=data.city.name;
            document.querySelector("#dt_main").innerHTML=(data.list[0].dt_txt).slice(0,10);
            document.querySelector("#descript").innerHTML=data.list[0].weather[0].description;
            //details
            document.querySelector("#humid").innerHTML="💧"+data.list[0].main.humidity+"%";
            document.querySelector("#pressure").innerHTML=data.list[0].main.pressure+"hpa";
            document.querySelector("#visibility").innerHTML=((data.list[0].visibility)/1000)+"km";
            document.querySelector("#feels").innerHTML=data.list[0].main.feels_like+"°C";
            document.querySelector("#wind").innerHTML=Math.trunc(data.list[0].wind.speed)+"Km/h";
            let wicon = document.querySelector('.weather-icon');
            const icon = data.list[0].weather[0].icon;
            wicon.innerHTML = `<img src="icons/${icon}.png" class="weather-img">`;    
            //5days-forecast  
                //day-1
                let wicon1 = document.querySelector('.weather-icon-1');
                const icon1 = data.list[8].weather[0].icon;
            wicon1.innerHTML = `<img src="icons/${icon1}.png" class="weather-img-5d">`;
            document.querySelector("#temp_1").innerHTML=data.list[8].main.temp+"°C";
            document.querySelector('#des1').innerHTML=data.list[8].weather[0].description;
            var date = data.list[8].dt_txt;
            document.querySelector('#dt1d').innerHTML=date.slice(0,10);
                //day-2
                let wicon2 = document.querySelector('.weather-icon-2');
                const icon2 = data.list[16].weather[0].icon;
            wicon2.innerHTML = `<img src="icons/${icon2}.png" class="weather-img-5d">`;
            document.querySelector("#temp_2").innerHTML=data.list[16].main.temp+"°C";
            document.querySelector('#des2').innerHTML=data.list[16].weather[0].description;
            document.querySelector('#dt2d').innerHTML=(data.list[16].dt_txt).slice(0,10);
                //day-3
                let wicon3 = document.querySelector('.weather-icon-3');
                const icon3 = data.list[24].weather[0].icon;
            wicon3.innerHTML = `<img src="icons/${icon3}.png" class="weather-img-5d">`;
            document.querySelector("#temp_3").innerHTML=data.list[24].main.temp+"°C";
            document.querySelector('#des3').innerHTML=data.list[24].weather[0].description;
            document.querySelector('#dt3d').innerHTML=(data.list[24].dt_txt).slice(0,10);
                            //day-4
                let wicon4 = document.querySelector('.weather-icon-4');
                const icon4 = data.list[32].weather[0].icon;
            wicon4.innerHTML = `<img src="icons/${icon4}.png" class="weather-img-5d">`;
            document.querySelector("#temp_4").innerHTML=data.list[32].main.temp+"°C";
            document.querySelector('#des4').innerHTML=data.list[32].weather[0].description;
            document.querySelector('#dt4d').innerHTML=(data.list[32].dt_txt).slice(0,10);
                            //day-5
                let wicon5 = document.querySelector('.weather-icon-5');
                const icon5 = data.list[39].weather[0].icon;
            wicon5.innerHTML = `<img src="icons/${icon5}.png" class="weather-img-5d">`;
            document.querySelector("#temp_5").innerHTML=data.list[39].main.temp+"°C";
            document.querySelector('#des5').innerHTML=data.list[39].weather[0].description;
            document.querySelector('#dt5d').innerHTML=(data.list[39].dt_txt).slice(0,10);
           }

        WeatherChecker(url).then(
            function (){
                console.log("success");
            },
            function (){
                alert("city not found🥺!");
            }
        );
    
    }
    oup2();
  }


btn.addEventListener('click',oup);